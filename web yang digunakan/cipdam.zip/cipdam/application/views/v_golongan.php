 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Golongan
       
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Golongan</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="box">
            <div class="box-header">
              <button class="btn btn-primary fa fa-plus" data-toggle="modal" data-target="#modal-tambah"> Tambah</button>
            </div>

            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Golongan</th>
                    <th>Biaya Air</th>
                    <th>Biaya Adm</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
                    $no=1;
                    foreach($golongan as $data){ 
                  ?>
                    <tr>
                      <td><?= $no++; ?></td>
                      <td><?= $data->golongan ?></td>
                      <td><?= $data->biaya_air ?></td>
                      <td><?= $data->biaya_adm ?></td>
                      <td>
                        <a style="cursor: pointer;" onclick="select_data(
                          '<?= $data->idgolongan ?>',
                          '<?= $data->golongan ?>',
                          '<?= $data->biaya_air ?>',
                          '<?= $data->biaya_adm ?>'
                        )"><i data-toggle="modal" data-target="#modal-edit" class="btn btn-primary fa fa-pencil"></i></a>
                        <a href="<?php echo base_url().'golongan/action_hapus/'. $data->idgolongan ?>" onClick="return confirm('Apakah anda yakin menghapus data ini ?')"><i class="btn btn-danger fa fa-trash"></i></a>
                      </td>
                    </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
    </section>
  </div>


  <div class="modal fade" id="modal-tambah">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Tambah Data</h4>
              </div>
              <div class="modal-body">
              <form role="form" action="<?= base_url().'golongan/action_tambah' ?>" method="POST">
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Golongan</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="golongan" placeholder="Golongan">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Biaya Air</label>
                  <input type="text" class="form-control" id="exampleInputPassword1" name="biaya" placeholder="Biaya Air">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Biaya ADM</label>
                  <input type="text" class="form-control" id="exampleInputPassword1" name="biayaadm" placeholder="Biaya ADM">
                </div>
              </div>
            
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
              </form>
            </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>


        <div class="modal fade" id="modal-edit">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Edit Data</h4>
              </div>
              <div class="modal-body">
              <form role="form" action="<?= base_url().'golongan/action_edit' ?>" method="POST">
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Golongan</label>
                  <input type="hidden" class="form-control" id="idgolongan" name="idgolongan">
                  <input type="text" class="form-control" id="golongan" name="golongan" placeholder="Golongan">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Biaya Air</label>
                  <input type="text" class="form-control" id="biaya" name="biaya" placeholder="Biaya Air">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Biaya ADM</label>
                  <input type="text" class="form-control" id="biayaadm" name="biayaadm" placeholder="Biaya ADM">
                </div>
              </div>
            
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
              </form>
            </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>


<script type="text/javascript">
  function select_data($idgolongan,$golongan,$biaya_air,$biaya_adm){
      $('#idgolongan').val($idgolongan);
      $('#golongan').val($golongan);
      $('#biaya').val($biaya_air);
      $('#biayaadm').val($biaya_adm);
  }
</script>