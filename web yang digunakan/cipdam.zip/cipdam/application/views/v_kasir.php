 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Kasir
       
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Kasir</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="box">
            <div class="box-header">
              <button class="btn btn-primary fa fa-plus" data-toggle="modal" data-target="#modal-tambah"> Tambah</button>
            </div>

            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Id Kasir</th>
                    <th>Nama Kasir</th>
                    <th>Tempat/Tanggal Lahir</th>
                    <th>Jenis Kelamin</th>
                    <th>Alamat</th>
                    <th>No Hp</th>
                    <th>Email</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
                    $no=1;
                    foreach($kasir as $data){ 
                  ?>
                    <tr>
                      <td><?= $no++; ?></td>
                      <td><?= $data->idkasir ?></td>
                      <td><?= $data->nama_kasir ?></td>
                      <td><?= $data->tempat_lahir .' '. $data->tanggal_lahir ?></td>
                      <td><?= $data->jk ?></td>
                      <td><?= $data->alamat ?></td>
                      <td><?= $data->nohp ?></td>
                      <td><?= $data->email ?></td>
                      <td>
                        <a style="cursor: pointer;" onclick="select_data(
                          '<?= $data->idkasir ?>',
                          '<?= $data->nama_kasir ?>',
                          '<?= $data->tempat_lahir ?>',
                          '<?= $data->tanggal_lahir ?>',
                          '<?= $data->jk ?>',
                          '<?= $data->agama ?>',
                          '<?= $data->alamat ?>',
                          '<?= $data->nohp ?>',
                          '<?= $data->email ?>'
                        )" data-toggle="modal" data-target="#modal-edit" ><i  class="btn btn-primary fa fa-pencil"></i></a>
                        <a href="<?php echo base_url().'kasir/action_hapus/'. $data->idkasir ?>" onClick="return confirm('Apakah anda yakin menghapus data ini ?')"><i class="btn btn-danger fa fa-trash"></i></a>
                      </td>
                    </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
    </section>
  </div>


  <div class="modal fade" id="modal-tambah">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Default Modal</h4>
              </div>
              <div class="modal-body">
              <form role="form" action="<?= base_url().'kasir/action_tambah' ?>" method="POST">
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Id kasir</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="idkasir" placeholder="Id Kasir">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Nama Lengkap</label>
                  <input type="text" class="form-control" id="exampleInputPassword1" name="nama" placeholder="Nama Lengkap">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Tempat Lahir</label>
                  <input type="text" class="form-control" id="exampleInputPassword1" name="tempat" placeholder="Tempat lahir">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Tanggal Lahir</label>
                  <input type="text" class="form-control datepicker" id="exampleInputPassword1" name="tgl_lahir">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Jenis Kelamin</label>
                  <div>
                  <input type="radio"  id="exampleInputPassword1" name="jk" value=
                  "Laki-laki" checked>Laki-laki
                  <input type="radio" id="exampleInputPassword1" name="jk" value="Perempuan">Perempuan
                </div>
                </div>
                 <div class="form-group">
                  <label for="exampleInputPassword1">Agama</label>
                    <select name="agama" class="form-control">
                      <option value="">-- Pilih Agama --</option>
                      <option value="Islam">Islam</option>
                      <option value="Kristen">Kristen</option>
                      <option value="Hindu">Hindu</option>
                      <option value="Budha">Budha</option>
                    </select>
                </div>
                 <div class="form-group">
                  <label for="exampleInputPassword1">Alamat</label>
                  <textarea type="text" class="form-control" id="exampleInputPassword1" name="alamat" placeholder="Pekerjaan"></textarea>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">No Hp</label>
                  <input type="text" class="form-control" id="exampleInputPassword1" name="nohp" placeholder="No Hp">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Email</label>
                  <input type="email" class="form-control" id="exampleInputPassword1" name="email" placeholder="Email">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Username</label>
                  <input type="text" class="form-control" id="exampleInputPassword1" name="username" placeholder="Email">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Password</label>
                  <input type="text" class="form-control" id="exampleInputPassword1" name="password" placeholder="Email">
                </div>
              </div>
            
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
              </form>
            </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>



<div class="modal fade" id="modal-edit">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Defaultdal</h4>
              </div>
              <div class="modal-body">
              <form role="form" action="<?= base_url().'kasir/action_edit' ?>" method="POST">
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Id kasir</label>
                  <input type="text" class="form-control" id="idkasir" name="idkasir" placeholder="Id Kasir">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Nama Lengkap</label>
                  <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Lengkap">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Tempat Lahir</label>
                  <input type="text" class="form-control" id="tempat" name="tempat" placeholder="Tempat lahir">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Tanggal Lahir</label>
                  <input type="text" class="form-control datepicker" id="tgl_lahir" name="tgl_lahir">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Jenis Kelamin</label>
                  <div>
                  <input type="radio"  id="jk" name="jk" value=
                  "Laki-laki" checked>Laki-laki
                  <input type="radio" id="jk" name="jk" value="Perempuan">Perempuan
                </div>
                </div>
                 <div class="form-group">
                  <label for="exampleInputPassword1">Agama</label>
                    <select name="agama" id="agama" class="form-control">
                      <option value="">-- Pilih Agama --</option>
                      <option value="Islam">Islam</option>
                      <option value="Kristen">Kristen</option>
                      <option value="Hindu">Hindu</option>
                      <option value="Budha">Budha</option>
                    </select>
                </div>
                 <div class="form-group">
                  <label for="exampleInputPassword1">Alamat</label>
                  <textarea type="text" class="form-control" id="alamat" name="alamat" placeholder="Pekerjaan"></textarea>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">No Hp</label>
                  <input type="text" class="form-control" id="nohp" name="nohp" placeholder="No Hp">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Email</label>
                  <input type="email" class="form-control" id="email" name="email" placeholder="Email">
                </div>
              </div>
            
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
              </form>
            </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>


<script type="text/javascript">
  function select_data($idkasir,$nama_kasir,$tempat_lahir,$tanggal_lahir,$jk,$agama,$alamat,$nohp,$email){
    $("#idkasir").val($idkasir);
    $("#nama").val($nama_kasir);
    $("#tempat").val($tempat_lahir);
    $("#tgl_lahir").val($tanggal_lahir);
    $("#jk").val($jk);
    $("#agama").val($agama);
    $("#alamat").val($alamat);
    $("#nohp").val($nohp);
    $("#email").val($email);
  }
</script>

 