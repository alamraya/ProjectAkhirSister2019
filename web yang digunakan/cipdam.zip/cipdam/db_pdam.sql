-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2019 at 08:59 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.0.28

SET SQL_MODE
= "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT
= 0;
START TRANSACTION;
SET time_zone
= "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pdam`
--

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu`
(
  `id` int
(11) NOT NULL,
  `judul_menu` varchar
(30) NOT NULL,
  `link` varchar
(30) NOT NULL,
  `icon` varchar
(20) NOT NULL,
  `is_main_menu` int
(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`
id`,
`judul_menu
`, `link`, `icon`, `is_main_menu`) VALUES
(1, 'Home', 'utama', 'fa fa-dashboard', 0),
(2, 'Data master', '#', 'fa fa-database', 0),
(3, 'Pelanggan', 'pelanggan', 'fa fa-users', 2),
(4, 'Kasir', 'kasir', 'fa fa-users', 2),
(5, 'Tarif', 'tarif', 'fa fa-users', 0),
(6, 'Golongan', 'golongan', 'fa fa-users', 2),
(7, 'Pembayaran', 'pembayaran', 'fa fa-money', 0),
(8, 'Data Pembayaran', 'pembayaran/datapembayaran', 'fa fa-table', 0),
(9, 'Laporan', '#', 'fa fa-file-pdf-o', 0),
(10, 'Laporan Golongan', 'golongan/cetak', 'fa fa-file-pdf-o', 9),
(11, 'Laporan Pelanggan', 'pelanggan/cetak', 'fa fa-file-pdf-o', 9),
(12, 'Laporan Pembayaran', 'pembayaran/cetakall', 'fa fa-file-pdf-o', 9);

-- --------------------------------------------------------

--
-- Table structure for table `menu_kasir`
--

CREATE TABLE `menu_kasir`
(
  `id` int
(11) NOT NULL,
  `judul_menu` varchar
(30) NOT NULL,
  `link` varchar
(30) NOT NULL,
  `icon` varchar
(20) NOT NULL,
  `is_main_menu` int
(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_kasir`
--

INSERT INTO `menu_kasir` (`
id`,
`judul_menu
`, `link`, `icon`, `is_main_menu`) VALUES
(1, 'Home', 'utama', 'fa fa-dashboard', 0),
(2, 'Data master', '#', 'fa fa-database', 0),
(3, 'Pelanggan', 'pelanggan', 'fa fa-users', 2),
(7, 'Pembayaran', 'pembayaran', 'fa fa-money', 0),
(8, 'Data Pembayaran', 'pembayaran/datapembayaran', 'fa fa-table', 0),
(9, 'Laporan', '#', 'fa fa-file-pdf-o', 0),
(12, 'Laporan Pembayaran', 'pembayaran/cetakall', 'fa fa-file-pdf-o', 9);

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin`
(
  `idadmin` int
(11) NOT NULL,
  `nama_lengkap` varchar
(40) NOT NULL,
  `username` varchar
(20) NOT NULL,
  `password` varchar
(40) NOT NULL,
  `root` int
(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`
idadmin`,
`nama_lengkap
`, `username`, `password`, `root`) VALUES
(1, 'ihsanp&dewi', 'admin', 'admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_golongan`
--

CREATE TABLE `tb_golongan`
(
  `idgolongan` int
(11) NOT NULL,
  `golongan` varchar
(10) NOT NULL,
  `biaya_air` varchar
(15) NOT NULL,
  `biaya_adm` varchar
(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_golongan`
--

INSERT INTO `tb_golongan` (`
idgolongan`,
`golongan
`, `biaya_air`, `biaya_adm`) VALUES
(1, 'RT1', '10000', '5000'),
(3, 'RT2', '1000', '5000'),
(4, 'RT3', '2000', '400'),
(5, 'RT8', '1000', '100');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kasir`
--

CREATE TABLE `tb_kasir`
(
  `idkasir` varchar
(10) NOT NULL,
  `nama_kasir` varchar
(40) NOT NULL,
  `tempat_lahir` varchar
(40) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `jk` varchar
(15) NOT NULL,
  `agama` varchar
(15) NOT NULL,
  `alamat` text NOT NULL,
  `nohp` varchar
(13) NOT NULL,
  `email` varchar
(40) NOT NULL,
  `username` varchar
(40) NOT NULL,
  `password` varchar
(40) NOT NULL,
  `root` int
(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kasir`
--

INSERT INTO `tb_kasir` (`
idkasir`,
`nama_kasir`,
`tempat_lahir`,
`tanggal_lahir
`, `jk`, `agama`, `alamat`, `nohp`, `email`, `username`, `password`, `root`) VALUES
('K001', 'Ahmad Fajri', 'Padang ', '2019-02-12', 'Laki-laki', 'Kristen', 'Solok', '08238787', 'fajri@gmail.com', 'kasir', 'kasir', 2),
('KS002', 'Titi', 'Padang Panjan', '2019-02-20', 'Perempuan', 'Islam', 'Swastaa', '082387584', 'ttiti@gmail.com', '', '', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pelanggan`
--

CREATE TABLE `tb_pelanggan`
(
  `no_pelanggan` varchar
(15) NOT NULL,
  `no_rekening` varchar
(20) NOT NULL,
  `idgolongan` int
(11) NOT NULL,
  `noktp` varchar
(20) NOT NULL,
  `nama_lengkap` varchar
(40) NOT NULL,
  `tempat_lahir` varchar
(40) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `agama` varchar
(15) NOT NULL,
  `alamat` text NOT NULL,
  `pekerjaan` varchar
(30) NOT NULL,
  `password` varchar
(40) NOT NULL,
  `root` int
(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pelanggan`
--

INSERT INTO `tb_pelanggan` (`
no_pelanggan`,
`no_rekening`,
`idgolongan`,
`noktp
`, `nama_lengkap`, `tempat_lahir`, `tanggal_lahir`, `agama`, `alamat`, `pekerjaan`, `password`, `root`) VALUES
('P001', '1234568', 1, '1234544', 'Dewi rosanti', 'Padang Panjang', '2019-02-19', 'Islam', 'aaa', 'Swasta', '', 3),
('P002', '33222', 2, '123343', 'Dila Prima Susanti', 'sad', '2019-02-14', 'Islam', 'wsss', 'sd', '', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pembayaran`
--

CREATE TABLE `tb_pembayaran`
(
  `kode_bayar` varchar
(15) NOT NULL,
  `no_pelanggan` varchar
(10) NOT NULL,
  `bulan_bayar` varchar
(20) NOT NULL,
  `jumlah_bayar` varchar
(15) NOT NULL,
  `tanggal_bayar` date NOT NULL,
  `status_bayar` varchar
(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pembayaran`
--

INSERT INTO `tb_pembayaran` (`
kode_bayar`,
`no_pelanggan
`, `bulan_bayar`, `jumlah_bayar`, `tanggal_bayar`, `status_bayar`) VALUES
('PA1903030179', 'P001', 'Februari 2019', '305000', '2019-03-01', 'Lunas'),
('PA1903030266', 'p001', 'Mei 2019', '205000', '2019-03-02', 'Lunas');

-- --------------------------------------------------------

--
-- Table structure for table `tb_tarif`
--

CREATE TABLE `tb_tarif`
(
  `id_tarif` int
(11) NOT NULL,
  `no_pelanggan` varchar
(20) NOT NULL,
  `idgolongan` int
(11) NOT NULL,
  `bulan_rekening` varchar
(20) NOT NULL,
  `mawal` varchar
(10) NOT NULL,
  `makhir` varchar
(10) NOT NULL,
  `pemakaian` varchar
(10) NOT NULL,
  `denda` varchar
(15) NOT NULL,
  `total_bayar` varchar
(15) NOT NULL,
  `input_oleh` int
(11) NOT NULL,
  `tanggal_data` date NOT NULL,
  `status` varchar
(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_tarif`
--

INSERT INTO `tb_tarif` (`
id_tarif`,
`no_pelanggan`,
`idgolongan`,
`bulan_rekening
`, `mawal`, `makhir`, `pemakaian`, `denda`, `total_bayar`, `input_oleh`, `tanggal_data`, `status`) VALUES
(10, 'P001', 1, 'Februari 2019', '20', '50', '30', '', '305000', 1, '2019-03-01', 'Lunas'),
(11, 'P001', 1, 'Mei 2019', '20', '40', '20', '', '205000', 1, '2019-03-01', 'Lunas');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
ADD PRIMARY KEY
(`id`);

--
-- Indexes for table `menu_kasir`
--
ALTER TABLE `menu_kasir`
ADD PRIMARY KEY
(`id`);

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
ADD PRIMARY KEY
(`idadmin`);

--
-- Indexes for table `tb_golongan`
--
ALTER TABLE `tb_golongan`
ADD PRIMARY KEY
(`idgolongan`);

--
-- Indexes for table `tb_kasir`
--
ALTER TABLE `tb_kasir`
ADD PRIMARY KEY
(`idkasir`);

--
-- Indexes for table `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
ADD PRIMARY KEY
(`no_pelanggan`);

--
-- Indexes for table `tb_pembayaran`
--
ALTER TABLE `tb_pembayaran`
ADD PRIMARY KEY
(`kode_bayar`);

--
-- Indexes for table `tb_tarif`
--
ALTER TABLE `tb_tarif`
ADD PRIMARY KEY
(`id_tarif`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `idadmin` int
(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_golongan`
--
ALTER TABLE `tb_golongan`
  MODIFY `idgolongan` int
(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tb_tarif`
--
ALTER TABLE `tb_tarif`
  MODIFY `id_tarif` int
(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
